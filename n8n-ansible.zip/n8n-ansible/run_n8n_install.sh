#!/bin/bash

# Переход в директорию скрипта (на случай запуска из другого места)
cd "$(dirname "$0")"

# Проверка наличия ansible
if ! command -v ansible-playbook &> /dev/null; then
    echo "❌ Ansible не установлен. Установим..."
    sudo apt update && sudo apt install -y ansible
fi

echo "✅ Запускаем установку n8n через Ansible..."
ansible-playbook -i inventory install_n8n.yml
